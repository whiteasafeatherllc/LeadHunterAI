
// Set this to your deployed backend URL (e.g., https://leadhunterai.onrender.com).
// Leave empty string to use same origin (for local testing).
window.LEADHUNTERAI_BACKEND = "";
